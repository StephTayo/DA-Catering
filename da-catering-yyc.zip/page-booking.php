﻿<?php
/*
Template Name: Booking Page
*/
get_header();
include get_template_directory() . '/templates/booking.php';
get_footer();
