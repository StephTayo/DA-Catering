﻿<?php
/*
Template Name: Home Page
*/
get_header();
include get_template_directory() . '/templates/index.php';
get_footer();
