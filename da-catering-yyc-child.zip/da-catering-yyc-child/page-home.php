﻿<?php
/*
Template Name: Home Page
*/
get_header();
include get_stylesheet_directory() . '/templates/index.php';
get_footer();
