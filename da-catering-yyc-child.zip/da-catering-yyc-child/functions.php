<?php
if (!defined('ABSPATH')) {
    exit;
}

function da_catering_yyc_child_enqueue_styles() {
    $parent_style = 'da-catering-yyc-style';
    wp_enqueue_style(
        $parent_style,
        get_template_directory_uri() . '/assets/css/style.css'
    );
    if (is_page_template('page-booking.php')) {
        wp_enqueue_style(
            'da-catering-yyc-child-booking-fonts',
            'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700;800;900&display=swap',
            array(),
            null
        );
    }
    wp_enqueue_style(
        'da-catering-yyc-child-style',
        get_stylesheet_uri(),
        array($parent_style),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'da_catering_yyc_child_enqueue_styles');

function da_catering_yyc_child_enqueue_scripts() {
    wp_dequeue_script('da-catering-yyc-main');
    wp_enqueue_script(
        'da-catering-yyc-child-main',
        get_stylesheet_directory_uri() . '/assets/js/main.js',
        array(),
        wp_get_theme()->get('Version'),
        true
    );
    wp_localize_script(
        'da-catering-yyc-child-main',
        'daNewsletter',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php', 'https'),
            'nonce' => wp_create_nonce('da_newsletter_subscribe'),
        )
    );
    wp_localize_script(
        'da-catering-yyc-child-main',
        'daOrder',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php', 'https'),
            'nonce' => wp_create_nonce('da_order_submit'),
        )
    );
    wp_localize_script(
        'da-catering-yyc-child-main',
        'daBooking',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php', 'https'),
            'nonce' => wp_create_nonce('da_booking_submit'),
        )
    );
}
add_action('wp_enqueue_scripts', 'da_catering_yyc_child_enqueue_scripts', 20);
add_action('after_setup_theme', function () {
    add_theme_support('post-thumbnails');
});

// Performance: add preconnects and defer main script.
add_filter('wp_resource_hints', function ($hints, $relation_type) {
    if ($relation_type === 'preconnect') {
        $hints[] = 'https://fonts.googleapis.com';
        $hints[] = 'https://fonts.gstatic.com';
        $hints[] = 'https://images.unsplash.com';
        $hints[] = 'https://upload.wikimedia.org';
    }
    return $hints;
}, 10, 2);

add_filter('script_loader_tag', function ($tag, $handle) {
    if ($handle === 'da-catering-yyc-child-main') {
        return str_replace(' src', ' defer src', $tag);
    }
    return $tag;
}, 10, 2);

add_filter('wp_lazy_loading_enabled', '__return_true');

function da_catering_yyc_child_allow_logo_uploads($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['webp'] = 'image/webp';
    return $mimes;
}
add_filter('upload_mimes', 'da_catering_yyc_child_allow_logo_uploads');

function da_catering_yyc_child_fix_svg_display($data, $file, $filename, $mimes) {
    if (strpos((string) $filename, '.svg') !== false) {
        $data['ext'] = 'svg';
        $data['type'] = 'image/svg+xml';
    }
    return $data;
}
add_filter('wp_check_filetype_and_ext', 'da_catering_yyc_child_fix_svg_display', 10, 4);

// Avoid media upload errors from generating oversized image variants.
add_filter('intermediate_image_sizes_advanced', function ($sizes) {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
        return $sizes;
    }
    foreach ($sizes as $name => $data) {
        $width = isset($data['width']) ? (int) $data['width'] : 0;
        $height = isset($data['height']) ? (int) $data['height'] : 0;
        if ($width > 2000 || $height > 2000) {
            unset($sizes[$name]);
        }
    }
    return $sizes;
}, 10, 1);

// Prevent large image downscaling which can fail on some hosts.
add_filter('big_image_size_threshold', function ($threshold) {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
        return $threshold;
    }
    return false;
});

// Disable all intermediate sizes to avoid server-side resize failures.
add_filter('intermediate_image_sizes_advanced', function ($sizes) {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
        return $sizes;
    }
    return array();
}, 99, 1);

// Prevent PHP warnings/notices from breaking async media upload responses.
add_action('admin_init', function () {
    // In admin, remove any front-end image size filters that can break uploads.
    remove_all_filters('intermediate_image_sizes_advanced');
    remove_all_filters('big_image_size_threshold');
    if (defined('DOING_AJAX') && DOING_AJAX) {
        @ini_set('display_errors', '0');
    }
});

function da_catering_yyc_child_admin_media_fix($hook) {
    if ($hook !== 'upload.php') {
        return;
    }
    wp_enqueue_script(
        'da-catering-yyc-child-admin-media-fix',
        get_stylesheet_directory_uri() . '/assets/js/admin-media-fix.js',
        array('jquery'),
        wp_get_theme()->get('Version'),
        true
    );
}
add_action('admin_enqueue_scripts', 'da_catering_yyc_child_admin_media_fix');

// Ensure Customizer media scripts are loaded (prevents blank media frame).
function da_catering_yyc_child_customizer_media_support() {
    wp_enqueue_media();
    wp_enqueue_style('media-views');
    wp_enqueue_script('media-views');
    wp_enqueue_script('media-models');
    wp_enqueue_script('media-editor');
    wp_enqueue_script('wp-api-request');
    wp_enqueue_script(
        'da-catering-yyc-child-customizer-media-fix',
        get_stylesheet_directory_uri() . '/assets/js/customizer-media-fix.js',
        array('jquery'),
        wp_get_theme()->get('Version'),
        true
    );
    wp_localize_script(
        'da-catering-yyc-child-customizer-media-fix',
        'daMediaFix',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'mediaNonce' => wp_create_nonce('media-form'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'restUrl' => esc_url_raw(rest_url()),
        )
    );
}
add_action('customize_controls_enqueue_scripts', 'da_catering_yyc_child_customizer_media_support', 20);

// Ensure media templates exist in Customizer controls footer.
function da_catering_yyc_child_print_customizer_media_templates() {
    if (function_exists('wp_print_media_templates')) {
        wp_print_media_templates();
    }
}
add_action('customize_controls_print_footer_scripts', 'da_catering_yyc_child_print_customizer_media_templates', 5);

// Force custom logo output to use the theme asset (bypass broken media picker).
function da_catering_yyc_child_force_custom_logo($html) {
    $logo_url = get_stylesheet_directory_uri() . '/assets/img/DA Catering Logo.png';
    $home_url = home_url('/');
    $alt = 'DA Catering YYC logo';
    return '<a href="' . esc_url($home_url) . '" class="custom-logo-link" rel="home" aria-current="page">' .
        '<img src="' . esc_url($logo_url) . '" class="custom-logo" alt="' . esc_attr($alt) . '" decoding="async" />' .
        '</a>';
}
add_filter('get_custom_logo', 'da_catering_yyc_child_force_custom_logo', 20);

// Force site icon URLs to the theme assets so favicons update immediately.
function da_catering_yyc_child_force_site_icon($url, $size, $blog_id) {
    $base = get_stylesheet_directory_uri() . '/assets/img';
    if ((int) $size === 32) {
        return $base . '/favicon-32x32.png';
    }
    if ((int) $size === 180) {
        return $base . '/apple-touch-icon.png';
    }
    if ((int) $size === 512) {
        return $base . '/icon-512x512.png';
    }
    return $base . '/favicon-32x32.png';
}
add_filter('get_site_icon_url', 'da_catering_yyc_child_force_site_icon', 20, 3);

// Force media modal to use admin-ajax settings (helps when REST is blocked in Customizer).
add_filter('media_view_settings', function ($settings) {
    if (is_admin() || is_customize_preview()) {
        $settings['ajaxurl'] = admin_url('admin-ajax.php');
        $settings['nonce'] = wp_create_nonce('media-form');
        $settings['post'] = array('id' => 0);
    }
    return $settings;
});

function da_catering_yyc_child_redirect_shop() {
    if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }

    if (class_exists('WooCommerce')) {
        return;
    }

    $request_path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');

    if (is_page('shop') || $request_path === 'shop') {
        wp_safe_redirect(home_url('/booking/?quick_order=1'), 301);
        exit;
    }
}
add_action('template_redirect', 'da_catering_yyc_child_redirect_shop');

function da_catering_yyc_child_force_booking_template($template) {
    if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return $template;
    }

    $request_path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    if ($request_path !== 'booking') {
        return $template;
    }

    $booking_template = locate_template('page-booking.php');
    if ($booking_template) {
        status_header(200);
        return $booking_template;
    }

    $parent_booking = get_template_directory() . '/page-booking.php';
    if (file_exists($parent_booking)) {
        status_header(200);
        return $parent_booking;
    }

    return $template;
}
add_filter('template_include', 'da_catering_yyc_child_force_booking_template');

function da_catering_yyc_child_register_newsletter_table() {
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }

    $option_key = 'da_newsletter_table_created';
    if (get_option($option_key)) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'da_newsletter';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        email VARCHAR(190) NOT NULL,
        created_at DATETIME NOT NULL,
        confirmed_at DATETIME NULL,
        unsubscribed_at DATETIME NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        token VARCHAR(64) NOT NULL,
        ip_address VARCHAR(45) NULL,
        user_agent TEXT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY email (email)
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    update_option($option_key, 1);
}
add_action('init', 'da_catering_yyc_child_register_newsletter_table');

function da_catering_yyc_child_generate_newsletter_token() {
    return bin2hex(random_bytes(16));
}

function da_catering_yyc_child_send_confirmation_email($email, $token) {
    $confirm_url = home_url('/?da_newsletter_confirm=' . urlencode($token));
    $unsub_url = home_url('/?da_newsletter_unsub=' . urlencode($token));
    $subject = 'Confirm your newsletter subscription';
    $brand = 'DA Catering YYC';
    $logo_id = get_theme_mod('custom_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          ' . ($logo_url ? '<div style="text-align:center;margin-bottom:18px;"><img src="' . esc_url($logo_url) . '" alt="' . esc_attr($brand) . '" style="max-width:160px;height:auto;" /></div>' : '') . '
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">Welcome to DA Catering YYC — Home of Quality Meals!</h2>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">We’re excited to have you. Click the button below to confirm your email and stay updated on our delicious deals and exclusive promos.</p>
          <p style="margin:24px 0;">
            <a href="' . esc_url($confirm_url) . '" style="display:inline-block;padding:12px 20px;background:#d46a1f;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;">Confirm subscription</a>
          </p>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">If you did not request this, you can ignore this email.</p>
          <p style="margin:0;color:#6b7280;font-size:12px;">Unsubscribe anytime: <a href="' . esc_url($unsub_url) . '" style="color:#6b7280;">' . esc_html($unsub_url) . '</a></p>
        </div>
        <p style="text-align:center;margin:16px 0 0;color:#9aa3a0;font-size:12px;">&copy; ' . date('Y') . ' ' . esc_html($brand) . '</p>
      </div>
    ';
    $headers = array('Content-Type: text/html; charset=UTF-8');
    wp_mail($email, $subject, $message, $headers);
}

function da_catering_yyc_child_handle_newsletter_subscribe() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!$nonce || !wp_verify_nonce($nonce, 'da_newsletter_subscribe')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'), 403);
    }

    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $honeypot = isset($_POST['company']) ? sanitize_text_field(wp_unslash($_POST['company'])) : '';

    if ($honeypot !== '') {
        wp_send_json_success(array('message' => 'Thanks! Please check your email to confirm.'));
    }

    if (!$email || !is_email($email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'));
    }

    $rate_email = $email ? strtolower($email) : 'unknown';
    $rate_key = 'da_newsletter_rl_' . md5($rate_email);
    $rate = (int) get_transient($rate_key);
    if ($rate >= 5) {
        wp_send_json_error(array('message' => 'Too many attempts. Please try again later.'));
    }
    set_transient($rate_key, $rate + 1, HOUR_IN_SECONDS);

    global $wpdb;
    $table = $wpdb->prefix . 'da_newsletter';
    $existing = $wpdb->get_row($wpdb->prepare("SELECT id, status, token, unsubscribed_at FROM {$table} WHERE email = %s", $email));
    if ($existing) {
        if ($existing->status === 'confirmed' && empty($existing->unsubscribed_at)) {
            wp_send_json_success(array('message' => "You're already subscribed."));
        }

        $token = da_catering_yyc_child_generate_newsletter_token();
        $wpdb->update(
            $table,
            array(
                'status' => 'pending',
                'token' => $token,
                'unsubscribed_at' => null,
            ),
            array('id' => $existing->id),
            array('%s', '%s', '%s'),
            array('%d')
        );
        da_catering_yyc_child_send_confirmation_email($email, $token);
        delete_transient($rate_key);
        wp_send_json_success(array('message' => 'Check your email to confirm your subscription.'));
    }

    $token = da_catering_yyc_child_generate_newsletter_token();
    $inserted = $wpdb->insert(
        $table,
        array(
            'email' => $email,
            'created_at' => current_time('mysql'),
            'status' => 'pending',
            'token' => $token,
            'ip_address' => $ip,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        ),
        array('%s', '%s', '%s', '%s', '%s', '%s')
    );

    if (!$inserted) {
        wp_send_json_error(array('message' => 'Sorry, something went wrong. Please try again.'));
    }

    da_catering_yyc_child_send_confirmation_email($email, $token);
    delete_transient($rate_key);

    wp_send_json_success(array('message' => 'Check your email to confirm your subscription.'));
}
add_action('wp_ajax_da_newsletter_subscribe', 'da_catering_yyc_child_handle_newsletter_subscribe');
add_action('wp_ajax_nopriv_da_newsletter_subscribe', 'da_catering_yyc_child_handle_newsletter_subscribe');

function da_catering_yyc_child_handle_newsletter_actions() {
    $token = '';
    $action = '';
    if (isset($_GET['da_newsletter_confirm'])) {
        $token = sanitize_text_field(wp_unslash($_GET['da_newsletter_confirm']));
        $action = 'confirm';
    } elseif (isset($_GET['da_newsletter_unsub'])) {
        $token = sanitize_text_field(wp_unslash($_GET['da_newsletter_unsub']));
        $action = 'unsub';
    }

    if (!$token || !$action) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'da_newsletter';
    $row = $wpdb->get_row($wpdb->prepare("SELECT id, email, status FROM {$table} WHERE token = %s", $token));

    if (!$row) {
        wp_die('Invalid or expired link. Please contact us for help.', 'Newsletter', array('response' => 404));
    }

    if ($action === 'confirm') {
        $wpdb->update(
            $table,
            array(
                'status' => 'confirmed',
                'confirmed_at' => current_time('mysql'),
                'unsubscribed_at' => null,
            ),
            array('id' => $row->id),
            array('%s', '%s', '%s'),
            array('%d')
        );
        wp_die('Thanks! Your subscription is confirmed.', 'Newsletter');
    }

    if ($action === 'unsub') {
        $wpdb->update(
            $table,
            array(
                'status' => 'unsubscribed',
                'unsubscribed_at' => current_time('mysql'),
            ),
            array('id' => $row->id),
            array('%s', '%s'),
            array('%d')
        );
        wp_die('You have been unsubscribed.', 'Newsletter');
    }
}
add_action('template_redirect', 'da_catering_yyc_child_handle_newsletter_actions');

function da_catering_yyc_child_newsletter_admin_menu() {
    add_menu_page(
        'Newsletter Subscribers',
        'Newsletter',
        'manage_options',
        'da-newsletter',
        'da_catering_yyc_child_render_newsletter_admin',
        'dashicons-email-alt',
        61
    );
}
add_action('admin_menu', 'da_catering_yyc_child_newsletter_admin_menu');

function da_catering_yyc_child_render_newsletter_admin() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_GET['da_newsletter_export']) && wp_verify_nonce($_GET['_wpnonce'] ?? '', 'da_newsletter_export')) {
        da_catering_yyc_child_export_newsletter_csv();
        exit;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'da_newsletter';
    $subscribers = $wpdb->get_results("SELECT id, email, status, created_at, confirmed_at, unsubscribed_at, ip_address FROM {$table} ORDER BY created_at DESC LIMIT 500");
    $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
    $export_url = wp_nonce_url(admin_url('admin.php?page=da-newsletter&da_newsletter_export=1'), 'da_newsletter_export');
    ?>
    <div class="wrap">
        <h1>Newsletter Subscribers</h1>
        <p>Total subscribers: <strong><?php echo esc_html($total); ?></strong></p>
        <p><a class="button button-primary" href="<?php echo esc_url($export_url); ?>">Download CSV</a></p>
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Subscribed</th>
                    <th>Confirmed</th>
                    <th>Unsubscribed</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($subscribers) : ?>
                    <?php foreach ($subscribers as $row) : ?>
                        <tr>
                            <td><?php echo esc_html($row->id); ?></td>
                            <td><?php echo esc_html($row->email); ?></td>
                            <td><?php echo esc_html($row->status); ?></td>
                            <td><?php echo esc_html($row->created_at); ?></td>
                            <td><?php echo esc_html($row->confirmed_at); ?></td>
                            <td><?php echo esc_html($row->unsubscribed_at); ?></td>
                            <td><?php echo esc_html($row->ip_address); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7">No subscribers yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <p style="margin-top:12px;color:#666;">Showing the latest 500 subscribers.</p>
    </div>
    <?php
}

function da_catering_yyc_child_export_newsletter_csv() {
    if (!current_user_can('manage_options')) {
        return;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'da_newsletter';
    $rows = $wpdb->get_results("SELECT email, status, created_at, confirmed_at, unsubscribed_at, ip_address, user_agent FROM {$table} ORDER BY created_at DESC", ARRAY_A);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=da-newsletter-subscribers.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, array('Email', 'Status', 'Subscribed At', 'Confirmed At', 'Unsubscribed At', 'IP Address', 'User Agent'));
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// Promo modal: allow admins to manage homepage promo posters.
function da_catering_yyc_child_register_promo_cpt() {
    $labels = array(
        'name' => 'Promos',
        'singular_name' => 'Promo',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Promo',
        'edit_item' => 'Edit Promo',
        'new_item' => 'New Promo',
        'view_item' => 'View Promo',
        'search_items' => 'Search Promos',
        'not_found' => 'No promos found',
        'not_found_in_trash' => 'No promos found in Trash',
    );

    register_post_type('da_promo', array(
        'labels' => $labels,
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-megaphone',
        'supports' => array('title', 'thumbnail'),
        'show_in_rest' => true,
        'exclude_from_search' => true,
        'publicly_queryable' => false,
    ));
}
add_action('init', 'da_catering_yyc_child_register_promo_cpt');

add_action('init', function () {
    add_post_type_support('da_promo', 'thumbnail');
});

function da_catering_yyc_child_add_promo_metabox() {
    add_meta_box('da_promo_details', 'Promo Details', 'da_catering_yyc_child_render_promo_metabox', 'da_promo', 'normal', 'high');
}
add_action('add_meta_boxes', 'da_catering_yyc_child_add_promo_metabox');

function da_catering_yyc_child_render_promo_metabox($post) {
    wp_nonce_field('da_promo_save', 'da_promo_nonce');
    $active = get_post_meta($post->ID, '_da_promo_active', true);
    $price = get_post_meta($post->ID, '_da_promo_price', true);
    $cta = get_post_meta($post->ID, '_da_promo_cta', true);
    $headline = get_post_meta($post->ID, '_da_promo_headline', true);
    $subline = get_post_meta($post->ID, '_da_promo_subline', true);
    $start = get_post_meta($post->ID, '_da_promo_start', true);
    $end = get_post_meta($post->ID, '_da_promo_end', true);
    $poster = get_post_meta($post->ID, '_da_promo_poster', true);
    ?>
    <p>
        <label>
            <input type="checkbox" name="da_promo_active" value="1" <?php checked($active, '1'); ?> />
            Active (show this promo modal on the website)
        </label>
    </p>
    <p>
        <label>Headline (optional)</label><br />
        <input type="text" name="da_promo_headline" value="<?php echo esc_attr($headline); ?>" style="width:100%;" />
    </p>
    <p>
        <label>Subheadline (optional)</label><br />
        <input type="text" name="da_promo_subline" value="<?php echo esc_attr($subline); ?>" style="width:100%;" />
    </p>
    <p>
        <label>CTA Button Label (optional)</label><br />
        <input type="text" name="da_promo_cta" value="<?php echo esc_attr($cta); ?>" style="width:100%;" placeholder="Quick Order" />
    </p>
    <p>
        <label>Package Price (numbers only)</label><br />
        <input type="number" name="da_promo_price" value="<?php echo esc_attr($price); ?>" step="0.01" min="0" />
    </p>
    <p>
        <label>Start Date (optional)</label><br />
        <input type="date" name="da_promo_start" value="<?php echo esc_attr($start); ?>" />
    </p>
    <p>
        <label>End Date (optional)</label><br />
        <input type="date" name="da_promo_end" value="<?php echo esc_attr($end); ?>" />
    </p>
    <p>
        <label>Promo Poster (fallback if Featured Image fails)</label><br />
        <input type="text" name="da_promo_poster" value="<?php echo esc_attr($poster); ?>" style="width:100%;" placeholder="Poster image URL" />
        <button type="button" class="button" data-promo-poster-upload>Select/Upload Poster</button>
    </p>
    <div data-promo-poster-preview style="margin:12px 0;max-width:320px;">
        <?php
        if ($poster) {
            echo '<img src="' . esc_url($poster) . '" alt="" style="max-width:100%;height:auto;border:1px solid rgba(31,61,52,0.12);border-radius:10px;" />';
        }
        ?>
    </div>
    <p style="margin-top:12px;color:#666;">Use the promo's Featured Image for the poster artwork.</p>
    <?php
}

function da_catering_yyc_child_save_promo_meta($post_id) {
    if (!isset($_POST['da_promo_nonce']) || !wp_verify_nonce($_POST['da_promo_nonce'], 'da_promo_save')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $active = isset($_POST['da_promo_active']) ? '1' : '0';
    update_post_meta($post_id, '_da_promo_active', $active);
    update_post_meta($post_id, '_da_promo_price', isset($_POST['da_promo_price']) ? sanitize_text_field(wp_unslash($_POST['da_promo_price'])) : '');
    update_post_meta($post_id, '_da_promo_cta', isset($_POST['da_promo_cta']) ? sanitize_text_field(wp_unslash($_POST['da_promo_cta'])) : '');
    update_post_meta($post_id, '_da_promo_headline', isset($_POST['da_promo_headline']) ? sanitize_text_field(wp_unslash($_POST['da_promo_headline'])) : '');
    update_post_meta($post_id, '_da_promo_subline', isset($_POST['da_promo_subline']) ? sanitize_text_field(wp_unslash($_POST['da_promo_subline'])) : '');
    update_post_meta($post_id, '_da_promo_start', isset($_POST['da_promo_start']) ? sanitize_text_field(wp_unslash($_POST['da_promo_start'])) : '');
    update_post_meta($post_id, '_da_promo_end', isset($_POST['da_promo_end']) ? sanitize_text_field(wp_unslash($_POST['da_promo_end'])) : '');
    update_post_meta($post_id, '_da_promo_poster', isset($_POST['da_promo_poster']) ? esc_url_raw(wp_unslash($_POST['da_promo_poster'])) : '');
}
add_action('save_post_da_promo', 'da_catering_yyc_child_save_promo_meta');

function da_catering_yyc_child_get_active_promo() {
    $args = array(
        'post_type' => 'da_promo',
        'post_status' => 'publish',
        'posts_per_page' => 5,
        'meta_key' => '_da_promo_active',
        'meta_value' => '1',
        'orderby' => 'date',
        'order' => 'DESC',
    );
    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return null;
    }

    $today = current_time('Y-m-d');
    foreach ($query->posts as $post) {
        $start = get_post_meta($post->ID, '_da_promo_start', true);
        $end = get_post_meta($post->ID, '_da_promo_end', true);
        if ($start && $start > $today) {
            continue;
        }
        if ($end && $end < $today) {
            continue;
        }
        if (!has_post_thumbnail($post)) {
            continue;
        }
        return $post;
    }
    return null;
}

function da_catering_yyc_child_render_promo_modal() {
    $promo = da_catering_yyc_child_get_active_promo();
    if (!$promo) {
        return;
    }

    $image = get_the_post_thumbnail_url($promo, 'large');
    if (!$image) {
        $image = get_post_meta($promo->ID, '_da_promo_poster', true);
    }
    $headline = get_post_meta($promo->ID, '_da_promo_headline', true);
    $subline = get_post_meta($promo->ID, '_da_promo_subline', true);
    $cta = get_post_meta($promo->ID, '_da_promo_cta', true);
    $price = get_post_meta($promo->ID, '_da_promo_price', true);
    $cta_text = $cta ? $cta : 'Quick Order';
    $promo_name = get_the_title($promo);

    $query_args = array(
        'quick_order' => '1',
        'promo' => $promo->ID,
        'promo_price' => $price,
        'promo_name' => $promo_name,
    );
    $promo_url = add_query_arg($query_args, home_url('/booking/'));
    ?>
    <div class="promo-modal" data-promo-modal data-promo-id="<?php echo esc_attr($promo->ID); ?>">
      <div class="promo-modal__backdrop" data-promo-close></div>
      <div class="promo-modal__dialog" role="dialog" aria-modal="true" aria-label="Promo">
        <button class="promo-modal__close" type="button" aria-label="Close" data-promo-close>×</button>
        <div class="promo-modal__media">
          <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($promo_name); ?> poster" loading="lazy" decoding="async" />
        </div>
        <div class="promo-modal__content">
          <h3><?php echo esc_html($headline ? $headline : $promo_name); ?></h3>
          <?php if ($subline) : ?>
            <p><?php echo esc_html($subline); ?></p>
          <?php endif; ?>
          <?php if ($price !== '') : ?>
            <div class="promo-modal__price">Package price: <strong>$<?php echo esc_html($price); ?></strong></div>
          <?php endif; ?>
          <a class="btn btn-primary promo-modal__cta" href="<?php echo esc_url($promo_url); ?>"><?php echo esc_html($cta_text); ?></a>
          <button class="btn btn-secondary promo-modal__dismiss" type="button" data-promo-close>Not now</button>
        </div>
      </div>
    </div>
    <?php
}
add_action('wp_footer', 'da_catering_yyc_child_render_promo_modal');

// Ensure media uploader works on Promo editor and add a poster picker fallback.
add_action('admin_enqueue_scripts', function ($hook) {
    if (!in_array($hook, array('post.php', 'post-new.php'), true)) {
        return;
    }
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'da_promo') {
        return;
    }
    wp_enqueue_media();
});

add_action('admin_footer', function () {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'da_promo') {
        return;
    }
    ?>
    <script>
      (function () {
        const button = document.querySelector('[data-promo-poster-upload]');
        const input = document.querySelector('input[name="da_promo_poster"]');
        const preview = document.querySelector('[data-promo-poster-preview]');
        if (!button || !input || !window.wp || !wp.media) return;

        let frame = null;
        button.addEventListener('click', function (e) {
          e.preventDefault();
          if (frame) {
            frame.open();
            return;
          }
          frame = wp.media({
            title: 'Select Promo Poster',
            button: { text: 'Use this poster' },
            multiple: false
          });
          frame.on('select', function () {
            const attachment = frame.state().get('selection').first().toJSON();
            if (!attachment || !attachment.url) return;
            input.value = attachment.url;
            if (preview) {
              preview.innerHTML = '<img src="' + attachment.url + '" alt="" style="max-width:100%;height:auto;border:1px solid rgba(31,61,52,0.12);border-radius:10px;" />';
            }
          });
          frame.open();
        });
      })();
    </script>
    <?php
});

// Set default email sender address/name.
add_filter('wp_mail_from', function ($from) {
    return 'deb@dacatering.ca';
});

add_filter('wp_mail_from_name', function ($name) {
    return 'DA Catering YYC';
});

// Optional SMTP configuration via wp-config.php constants.
add_action('phpmailer_init', function ($phpmailer) {
    if (!defined('DA_SMTP_HOST')) {
        return;
    }
    $phpmailer->isSMTP();
    $phpmailer->Host = DA_SMTP_HOST;
    $phpmailer->SMTPAuth = defined('DA_SMTP_USER');
    if (defined('DA_SMTP_USER')) {
        $phpmailer->Username = DA_SMTP_USER;
    }
    if (defined('DA_SMTP_PASS')) {
        $phpmailer->Password = DA_SMTP_PASS;
    }
    if (defined('DA_SMTP_PORT')) {
        $phpmailer->Port = (int) DA_SMTP_PORT;
    }
    if (defined('DA_SMTP_SECURE')) {
        $phpmailer->SMTPSecure = DA_SMTP_SECURE;
    }
    $phpmailer->From = 'orders@dacatering.ca';
    $phpmailer->FromName = 'DA Catering YYC';
});

function da_catering_yyc_child_get_menu_prices() {
    $base = array(
        'Jollof Rice' => 18,
        'Fried Rice' => 17,
        'Egusi Soup & Pounded Yam' => 22,
        'Semovita & Efo Riro' => 21,
        'Red Stew' => 19,
        'Ayamase (Ofada Stew)' => 22,
        'Suya Skewers' => 16,
        'Dodo (Fried Plantain)' => 12,
        'Puff Puff' => 10,
        'Moi Moi' => 14,
        'Asun (Spicy Goat)' => 23,
        'Okra Soup' => 19,
        'Tropical Mango Smoothie' => 8,
        'Orange Carrot Boost' => 7,
        'Party Tray: Jollof + Suya + Dodo' => 150,
        'Pineapple Ginger Zing' => 8,
        'Watermelon Cooler' => 7,
        'Berry Blast' => 8,
        'Zobo / Hibiscus Drink' => 6,
        'Kunu / Tigernut Drink' => 6,
        'Chapman' => 6,
        'Sobolo' => 6,
    );
    $json = get_option('da_menu_prices_json', '');
    if ($json) {
        $decoded = json_decode($json, true);
        if (is_array($decoded)) {
            foreach ($decoded as $name => $price) {
                if (!is_string($name) || $name === '') {
                    continue;
                }
                if (!is_numeric($price)) {
                    continue;
                }
                $base[$name] = (float) $price;
            }
        }
    }
    return $base;
}

function da_catering_yyc_child_rate_limit($key, $limit = 10, $window = HOUR_IN_SECONDS) {
    $count = (int) get_transient($key);
    if ($count >= $limit) {
        return false;
    }
    set_transient($key, $count + 1, $window);
    return true;
}

// Orders: store quick orders and email customer/admin with receipt action.
function da_catering_yyc_child_register_order_cpt() {
    register_post_type('da_order', array(
        'labels' => array(
            'name' => 'Orders',
            'singular_name' => 'Order',
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-cart',
        'supports' => array('title'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'da_catering_yyc_child_register_order_cpt');

add_action('admin_menu', function () {
    add_submenu_page(
        'edit.php?post_type=da_order',
        'Menu Prices',
        'Menu Prices',
        'manage_options',
        'da-menu-prices',
        'da_catering_yyc_child_render_menu_prices_page'
    );
});

function da_catering_yyc_child_render_menu_prices_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (isset($_POST['da_menu_prices_nonce']) && wp_verify_nonce($_POST['da_menu_prices_nonce'], 'da_menu_prices_save')) {
        $raw = wp_unslash($_POST['da_menu_prices_json'] ?? '');
        $trimmed = trim($raw);
        $decoded = $trimmed ? json_decode($trimmed, true) : array();
        if ($trimmed && !is_array($decoded)) {
            echo '<div class="notice notice-error"><p>Invalid JSON. Please fix the format.</p></div>';
        } else {
            update_option('da_menu_prices_json', $trimmed);
            echo '<div class="notice notice-success"><p>Menu prices updated.</p></div>';
        }
    }
    $current = get_option('da_menu_prices_json', '');
    ?>
    <div class="wrap">
        <h1>Menu Prices</h1>
        <p>Provide a JSON object of item name to price. Example:</p>
        <pre style="background:#f6f7f7;padding:12px;border-radius:6px;">{"Jollof Rice":18,"Fried Rice":17}</pre>
        <form method="post">
            <?php wp_nonce_field('da_menu_prices_save', 'da_menu_prices_nonce'); ?>
            <textarea name="da_menu_prices_json" rows="12" style="width:100%;max-width:900px;"><?php echo esc_textarea($current); ?></textarea>
            <p><button class="button button-primary" type="submit">Save Prices</button></p>
        </form>
    </div>
    <?php
}

add_filter('manage_da_order_posts_columns', function ($columns) {
    $columns['order_status'] = 'Status';
    $columns['order_total'] = 'Subtotal';
    $columns['order_email'] = 'Customer Email';
    $columns['order_phone'] = 'Phone';
    $columns['order_paid'] = 'Paid';
    return $columns;
});

add_action('manage_da_order_posts_custom_column', function ($column, $post_id) {
    if ($column === 'order_status') {
        $status = get_post_meta($post_id, '_da_order_status', true) ?: 'received';
        echo esc_html(ucwords(str_replace('_', ' ', $status)));
    }
    if ($column === 'order_total') {
        $subtotal = (float) get_post_meta($post_id, '_da_order_subtotal', true);
        echo esc_html(da_catering_yyc_child_format_money($subtotal));
    }
    if ($column === 'order_email') {
        $order = get_post_meta($post_id, '_da_order_data', true);
        echo esc_html(is_array($order) ? ($order['order_email'] ?? '') : '');
    }
    if ($column === 'order_phone') {
        $order = get_post_meta($post_id, '_da_order_data', true);
        echo esc_html(is_array($order) ? ($order['order_phone'] ?? '') : '');
    }
    if ($column === 'order_paid') {
        $paid = (int) get_post_meta($post_id, '_da_order_paid', true);
        echo $paid ? 'Yes' : 'No';
    }
}, 10, 2);

add_action('admin_head', function () {
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'da_order') {
        return;
    }
    echo '<style>
      .column-order_status { width: 120px; }
      .column-order_total { width: 120px; }
    </style>';
});

function da_catering_yyc_child_format_money($amount) {
    return '$' . number_format((float) $amount, 2);
}

function da_catering_yyc_child_build_items_table($items) {
    $rows = '';
    foreach ($items as $item) {
        $name = esc_html($item['name'] ?? '');
        $qty = (int) ($item['qty'] ?? 1);
        $price = (float) ($item['price'] ?? 0);
        $line = $qty * $price;
        $rows .= '<tr>
          <td style="padding:8px 0;border-bottom:1px solid #eee;">' . $name . '</td>
          <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:center;">' . $qty . '</td>
          <td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right;">' . da_catering_yyc_child_format_money($line) . '</td>
        </tr>';
    }
    return $rows;
}

function da_catering_yyc_child_send_order_confirmation($order_id, $order, $items, $subtotal) {
    $email = $order['order_email'];
    $brand = 'DA Catering YYC';
    $logo_id = get_theme_mod('custom_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';

    $items_rows = da_catering_yyc_child_build_items_table($items);
    $subject = 'Your order was received';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );

    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          ' . ($logo_url ? '<div style="text-align:center;margin-bottom:18px;"><img src="' . esc_url($logo_url) . '" alt="' . esc_attr($brand) . '" style="max-width:160px;height:auto;" /></div>' : '') . '
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">Thanks for your order!</h2>
          <p style="margin:0 0 12px;color:#4a5650;">Order #'. esc_html($order_id) .'</p>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">We have received your order and will follow up shortly. You will receive status updates by email.</p>
          <table style="width:100%;border-collapse:collapse;margin-top:12px;">
            <thead>
              <tr>
                <th style="text-align:left;padding-bottom:8px;border-bottom:2px solid #eee;">Item</th>
                <th style="text-align:center;padding-bottom:8px;border-bottom:2px solid #eee;">Qty</th>
                <th style="text-align:right;padding-bottom:8px;border-bottom:2px solid #eee;">Total</th>
              </tr>
            </thead>
            <tbody>
              ' . $items_rows . '
            </tbody>
          </table>
          <p style="margin:16px 0 0;text-align:right;font-weight:700;">Subtotal: ' . da_catering_yyc_child_format_money($subtotal) . '</p>
        </div>
        <p style="text-align:center;margin:16px 0 0;color:#9aa3a0;font-size:12px;">&copy; ' . date('Y') . ' ' . esc_html($brand) . '</p>
      </div>
    ';
    wp_mail($email, $subject, $message, $headers);
}

function da_catering_yyc_child_send_order_admin_notice($order_id, $order, $items, $subtotal) {
    $brand = 'DA Catering YYC';
    $receipt_token = get_post_meta($order_id, '_da_order_receipt_token', true);
    $receipt_url = add_query_arg('da_order_receipt', $receipt_token, home_url('/'));
    $paid_token = get_post_meta($order_id, '_da_order_paid_token', true);
    $paid_url = add_query_arg('da_order_paid', $paid_token, home_url('/'));
    $status_token = get_post_meta($order_id, '_da_order_status_token', true);
    $confirmed_url = add_query_arg(array('da_order_status' => $status_token, 'status' => 'confirmed'), home_url('/'));
    $progress_url = add_query_arg(array('da_order_status' => $status_token, 'status' => 'in_progress'), home_url('/'));
    $ready_url = add_query_arg(array('da_order_status' => $status_token, 'status' => 'ready'), home_url('/'));

    $items_rows = da_catering_yyc_child_build_items_table($items);
    $subject = 'New quick order received';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );

    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">New Quick Order</h2>
          <p style="margin:0 0 12px;color:#4a5650;">Order #'. esc_html($order_id) .'</p>
          <p style="margin:0 0 12px;color:#4a5650;">Customer: <strong>' . esc_html($order['order_name']) . '</strong></p>
          <p style="margin:0 0 12px;color:#4a5650;">Email: ' . esc_html($order['order_email']) . '</p>
          <p style="margin:0 0 12px;color:#4a5650;">Phone: ' . esc_html($order['order_phone']) . '</p>
          <p style="margin:0 0 12px;color:#4a5650;">Fulfillment: ' . esc_html($order['fulfillment']) . '</p>
          <p style="margin:0 0 12px;color:#4a5650;">Preferred time: ' . esc_html($order['order_time']) . '</p>
          ' . (!empty($order['delivery_address']) ? '<p style="margin:0 0 12px;color:#4a5650;">Delivery address: ' . esc_html($order['delivery_address']) . '</p>' : '') . '
          ' . (!empty($order['order_notes']) ? '<p style="margin:0 0 12px;color:#4a5650;">Notes: ' . esc_html($order['order_notes']) . '</p>' : '') . '
          <table style="width:100%;border-collapse:collapse;margin-top:12px;">
            <thead>
              <tr>
                <th style="text-align:left;padding-bottom:8px;border-bottom:2px solid #eee;">Item</th>
                <th style="text-align:center;padding-bottom:8px;border-bottom:2px solid #eee;">Qty</th>
                <th style="text-align:right;padding-bottom:8px;border-bottom:2px solid #eee;">Total</th>
              </tr>
            </thead>
            <tbody>
              ' . $items_rows . '
            </tbody>
          </table>
          <p style="margin:16px 0 0;text-align:right;font-weight:700;">Subtotal: ' . da_catering_yyc_child_format_money($subtotal) . '</p>
          <p style="margin:18px 0 0;">
            <a href="' . esc_url($receipt_url) . '" style="display:inline-block;padding:12px 18px;background:#d46a1f;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;">Send Receipt to Customer</a>
          </p>
          <p style="margin:12px 0 0;">
            <a href="' . esc_url($paid_url) . '" style="display:inline-block;padding:10px 16px;background:#1f3d34;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;">Mark as Paid</a>
          </p>
          <p style="margin:18px 0 0;">
            <a href="' . esc_url($confirmed_url) . '" style="display:inline-block;padding:10px 16px;background:#2563eb;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;">Confirm Order</a>
            <a href="' . esc_url($progress_url) . '" style="display:inline-block;padding:10px 16px;background:#0f766e;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;margin-left:6px;">In Progress</a>
            <a href="' . esc_url($ready_url) . '" style="display:inline-block;padding:10px 16px;background:#16a34a;color:#ffffff;text-decoration:none;border-radius:999px;font-weight:600;margin-left:6px;">Ready</a>
          </p>
        </div>
      </div>
    ';
    wp_mail('orders@dacatering.ca', $subject, $message, $headers);
}

function da_catering_yyc_child_send_order_receipt($order_id) {
    $order = get_post_meta($order_id, '_da_order_data', true);
    $items = get_post_meta($order_id, '_da_order_items', true);
    if (!is_array($order) || !is_array($items)) {
        return false;
    }

    $subtotal = (float) get_post_meta($order_id, '_da_order_subtotal', true);
    $email = $order['order_email'];
    $brand = 'DA Catering YYC';
    $logo_id = get_theme_mod('custom_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
    $items_rows = da_catering_yyc_child_build_items_table($items);
    $subject = 'Your receipt from DA Catering YYC';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );

    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          ' . ($logo_url ? '<div style="text-align:center;margin-bottom:18px;"><img src="' . esc_url($logo_url) . '" alt="' . esc_attr($brand) . '" style="max-width:160px;height:auto;" /></div>' : '') . '
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">Receipt</h2>
          <p style="margin:0 0 12px;color:#4a5650;">Order #'. esc_html($order_id) .'</p>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">Thank you for your payment. Here is your receipt.</p>
          <table style="width:100%;border-collapse:collapse;margin-top:12px;">
            <thead>
              <tr>
                <th style="text-align:left;padding-bottom:8px;border-bottom:2px solid #eee;">Item</th>
                <th style="text-align:center;padding-bottom:8px;border-bottom:2px solid #eee;">Qty</th>
                <th style="text-align:right;padding-bottom:8px;border-bottom:2px solid #eee;">Total</th>
              </tr>
            </thead>
            <tbody>
              ' . $items_rows . '
            </tbody>
          </table>
          <p style="margin:16px 0 0;text-align:right;font-weight:700;">Subtotal: ' . da_catering_yyc_child_format_money($subtotal) . '</p>
        </div>
        <p style="text-align:center;margin:16px 0 0;color:#9aa3a0;font-size:12px;">&copy; ' . date('Y') . ' ' . esc_html($brand) . '</p>
      </div>
    ';
    return wp_mail($email, $subject, $message, $headers);
}

function da_catering_yyc_child_send_order_status_email($order_id, $status) {
    $order = get_post_meta($order_id, '_da_order_data', true);
    if (!is_array($order)) {
        return false;
    }
    $email = $order['order_email'];
    $brand = 'DA Catering YYC';
    $logo_id = get_theme_mod('custom_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
    $status_map = array(
        'confirmed' => 'Order confirmed',
        'in_progress' => 'In progress',
        'ready' => 'Ready for pickup/delivery',
        'paid' => 'Payment received',
    );
    $status_label = $status_map[$status] ?? 'Order update';
    $subject = $status_label . ' - DA Catering YYC';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );
    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          ' . ($logo_url ? '<div style="text-align:center;margin-bottom:18px;"><img src="' . esc_url($logo_url) . '" alt="' . esc_attr($brand) . '" style="max-width:160px;height:auto;" /></div>' : '') . '
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">' . esc_html($status_label) . '</h2>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">Hi ' . esc_html($order['order_name']) . ', your order status is now: <strong>' . esc_html($status_label) . '</strong>.</p>
        </div>
        <p style="text-align:center;margin:16px 0 0;color:#9aa3a0;font-size:12px;">&copy; ' . date('Y') . ' ' . esc_html($brand) . '</p>
      </div>
    ';
    return wp_mail($email, $subject, $message, $headers);
}

function da_catering_yyc_child_send_booking_confirmation($booking) {
    $email = $booking['email'];
    $brand = 'DA Catering YYC';
    $logo_id = get_theme_mod('custom_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'full') : '';
    $subject = 'Your catering booking request was received';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );
    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          ' . ($logo_url ? '<div style="text-align:center;margin-bottom:18px;"><img src="' . esc_url($logo_url) . '" alt="' . esc_attr($brand) . '" style="max-width:160px;height:auto;" /></div>' : '') . '
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">Thanks for your booking request!</h2>
          <p style="margin:0 0 16px;color:#4a5650;line-height:1.6;">We have received your catering request and will get back to you within 2 hours.</p>
          <p style="margin:0 0 6px;color:#4a5650;"><strong>Event:</strong> ' . esc_html($booking['event_type']) . '</p>
          <p style="margin:0 0 6px;color:#4a5650;"><strong>Guests:</strong> ' . esc_html($booking['guest_count']) . '</p>
          <p style="margin:0 0 6px;color:#4a5650;"><strong>Date:</strong> ' . esc_html($booking['event_date']) . '</p>
          <p style="margin:0 0 6px;color:#4a5650;"><strong>Time:</strong> ' . esc_html($booking['event_time']) . '</p>
        </div>
        <p style="text-align:center;margin:16px 0 0;color:#9aa3a0;font-size:12px;">&copy; ' . date('Y') . ' ' . esc_html($brand) . '</p>
      </div>
    ';
    wp_mail($email, $subject, $message, $headers);
}

function da_catering_yyc_child_send_booking_admin_notice($booking) {
    $subject = 'New catering booking request';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: DA Catering YYC <orders@dacatering.ca>',
    );
    $message = '
      <div style="background:#f7f4ee;padding:24px 0;font-family:Arial, sans-serif;color:#1f3d34;">
        <div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:16px;padding:28px;border:1px solid rgba(31,61,52,0.12);">
          <h2 style="margin:0 0 12px;font-size:22px;color:#1f3d34;">New Catering Booking</h2>
          <p><strong>Name:</strong> ' . esc_html($booking['full_name']) . '</p>
          <p><strong>Email:</strong> ' . esc_html($booking['email']) . '</p>
          <p><strong>Phone:</strong> ' . esc_html($booking['phone']) . '</p>
          <p><strong>Event Type:</strong> ' . esc_html($booking['event_type']) . '</p>
          <p><strong>Guests:</strong> ' . esc_html($booking['guest_count']) . '</p>
          <p><strong>Date:</strong> ' . esc_html($booking['event_date']) . '</p>
          <p><strong>Time:</strong> ' . esc_html($booking['event_time']) . '</p>
          <p><strong>Budget:</strong> ' . esc_html($booking['budget_range']) . '</p>
          <p><strong>Service Type:</strong> ' . esc_html($booking['service_type']) . '</p>
          <p><strong>Address:</strong> ' . esc_html($booking['delivery_address']) . '</p>
          <p><strong>Delivery Instructions:</strong> ' . esc_html($booking['delivery_instructions']) . '</p>
          <p><strong>Dietary Restrictions:</strong> ' . esc_html($booking['dietary_restrictions']) . '</p>
          <p><strong>Special Requests:</strong> ' . esc_html($booking['special_requests']) . '</p>
        </div>
      </div>
    ';
    wp_mail('orders@dacatering.ca', $subject, $message, $headers);
}

function da_catering_yyc_child_handle_booking_submit() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!$nonce || !wp_verify_nonce($nonce, 'da_booking_submit')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'), 403);
    }

    $honeypot = isset($_POST['booking_company']) ? sanitize_text_field(wp_unslash($_POST['booking_company'])) : '';
    if ($honeypot !== '') {
        wp_send_json_success(array('message' => 'Booking request submitted.'));
    }

    $booking = array(
        'full_name' => sanitize_text_field(wp_unslash($_POST['full_name'] ?? '')),
        'email' => sanitize_email(wp_unslash($_POST['email'] ?? '')),
        'phone' => sanitize_text_field(wp_unslash($_POST['phone'] ?? '')),
        'event_type' => sanitize_text_field(wp_unslash($_POST['event_type'] ?? '')),
        'guest_count' => sanitize_text_field(wp_unslash($_POST['guest_count'] ?? '')),
        'event_date' => sanitize_text_field(wp_unslash($_POST['event_date'] ?? '')),
        'event_time' => sanitize_text_field(wp_unslash($_POST['event_time'] ?? '')),
        'budget_range' => sanitize_text_field(wp_unslash($_POST['budget_range'] ?? '')),
        'service_type' => sanitize_text_field(wp_unslash($_POST['service_type'] ?? '')),
        'delivery_address' => sanitize_textarea_field(wp_unslash($_POST['delivery_address'] ?? '')),
        'delivery_instructions' => sanitize_textarea_field(wp_unslash($_POST['delivery_instructions'] ?? '')),
        'dietary_restrictions' => sanitize_textarea_field(wp_unslash($_POST['dietary_restrictions'] ?? '')),
        'special_requests' => sanitize_textarea_field(wp_unslash($_POST['special_requests'] ?? '')),
    );

    if (!$booking['full_name'] || !$booking['email'] || !$booking['phone']) {
        wp_send_json_error(array('message' => 'Please complete all required fields.'));
    }

    $rate_key = 'da_booking_rl_' . md5(strtolower($booking['email'] ?: 'unknown'));
    if (!da_catering_yyc_child_rate_limit($rate_key, 5, HOUR_IN_SECONDS)) {
        wp_send_json_error(array('message' => 'Too many attempts. Please try again later.'));
    }

    da_catering_yyc_child_send_booking_confirmation($booking);
    da_catering_yyc_child_send_booking_admin_notice($booking);

    delete_transient($rate_key);
    wp_send_json_success(array('message' => 'Booking request submitted.'));
}
add_action('wp_ajax_da_booking_submit', 'da_catering_yyc_child_handle_booking_submit');
add_action('wp_ajax_nopriv_da_booking_submit', 'da_catering_yyc_child_handle_booking_submit');

function da_catering_yyc_child_handle_order_submit() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!$nonce || !wp_verify_nonce($nonce, 'da_order_submit')) {
        wp_send_json_error(array('message' => 'Security check failed. Please refresh and try again.'), 403);
    }

    $honeypot = isset($_POST['order_company']) ? sanitize_text_field(wp_unslash($_POST['order_company'])) : '';
    if ($honeypot !== '') {
        wp_send_json_success(array('message' => 'Order received.'));
    }

    $order = array(
        'order_name' => sanitize_text_field(wp_unslash($_POST['order_name'] ?? '')),
        'order_email' => sanitize_email(wp_unslash($_POST['order_email'] ?? '')),
        'order_phone' => sanitize_text_field(wp_unslash($_POST['order_phone'] ?? '')),
        'fulfillment' => sanitize_text_field(wp_unslash($_POST['fulfillment'] ?? 'pickup')),
        'order_time' => sanitize_text_field(wp_unslash($_POST['order_time'] ?? '')),
        'delivery_address' => sanitize_textarea_field(wp_unslash($_POST['delivery_address'] ?? '')),
        'order_notes' => sanitize_textarea_field(wp_unslash($_POST['order_notes'] ?? '')),
    );

    if (!$order['order_name'] || !$order['order_email'] || !$order['order_phone']) {
        wp_send_json_error(array('message' => 'Please complete all required fields.'));
    }

    $rate_key = 'da_order_rl_' . md5(strtolower($order['order_email'] ?: 'unknown'));
    if (!da_catering_yyc_child_rate_limit($rate_key, 10, HOUR_IN_SECONDS)) {
        wp_send_json_error(array('message' => 'Too many attempts. Please try again later.'));
    }

    $items_json = wp_unslash($_POST['items'] ?? '');
    $items = json_decode($items_json, true);
    if (!is_array($items) || empty($items)) {
        wp_send_json_error(array('message' => 'Your order is empty. Please add items.'));
    }

    $promo_meta_raw = wp_unslash($_POST['promo_meta'] ?? '');
    $promo_meta = $promo_meta_raw ? json_decode($promo_meta_raw, true) : null;
    $promo_allowed = array();
    if (is_array($promo_meta) && !empty($promo_meta['id'])) {
        $promo_id = (int) $promo_meta['id'];
        $promo_title = get_the_title($promo_id);
        $promo_price = get_post_meta($promo_id, '_da_promo_price', true);
        if ($promo_title && $promo_price !== '') {
            $promo_allowed[$promo_title] = (float) $promo_price;
        }
    }

    $price_list = da_catering_yyc_child_get_menu_prices();
    $validated_items = array();

    $subtotal = 0;
    foreach ($items as $item) {
        $name = isset($item['name']) ? sanitize_text_field($item['name']) : '';
        $qty = (int) ($item['qty'] ?? 1);
        if ($qty < 1) {
            $qty = 1;
        }
        if (!$name) {
            continue;
        }

        if (isset($promo_allowed[$name])) {
            $price = (float) $promo_allowed[$name];
        } elseif (isset($price_list[$name])) {
            $price = (float) $price_list[$name];
        } else {
            wp_send_json_error(array('message' => 'One or more items are unavailable. Please refresh the menu and try again.'));
        }

        $subtotal += $qty * $price;
        $validated_items[] = array(
            'name' => $name,
            'qty' => $qty,
            'price' => $price,
            'notes' => isset($item['notes']) ? sanitize_text_field($item['notes']) : '',
        );
    }

    $order_title = 'Order - ' . $order['order_name'] . ' - ' . current_time('Y-m-d H:i');
    $order_id = wp_insert_post(array(
        'post_type' => 'da_order',
        'post_status' => 'publish',
        'post_title' => $order_title,
    ));

    if (is_wp_error($order_id) || !$order_id) {
        wp_send_json_error(array('message' => 'Sorry, something went wrong. Please try again.'));
    }

    $token = bin2hex(random_bytes(16));
    $paid_token = bin2hex(random_bytes(16));
    update_post_meta($order_id, '_da_order_data', $order);
    update_post_meta($order_id, '_da_order_items', $validated_items);
    update_post_meta($order_id, '_da_order_subtotal', $subtotal);
    update_post_meta($order_id, '_da_order_receipt_token', $token);
    update_post_meta($order_id, '_da_order_receipt_sent', 0);
    update_post_meta($order_id, '_da_order_paid_token', $paid_token);
    update_post_meta($order_id, '_da_order_paid', 0);
    $status_token = bin2hex(random_bytes(16));
    update_post_meta($order_id, '_da_order_status', 'received');
    update_post_meta($order_id, '_da_order_status_token', $status_token);

    da_catering_yyc_child_send_order_confirmation($order_id, $order, $validated_items, $subtotal);
    da_catering_yyc_child_send_order_admin_notice($order_id, $order, $validated_items, $subtotal);

    delete_transient($rate_key);
    wp_send_json_success(array('message' => 'Order received.'));
}
add_action('wp_ajax_da_order_submit', 'da_catering_yyc_child_handle_order_submit');
add_action('wp_ajax_nopriv_da_order_submit', 'da_catering_yyc_child_handle_order_submit');

function da_catering_yyc_child_handle_order_receipt() {
    $token = isset($_GET['da_order_receipt']) ? sanitize_text_field(wp_unslash($_GET['da_order_receipt'])) : '';
    if (!$token) {
        return;
    }
    $query = new WP_Query(array(
        'post_type' => 'da_order',
        'post_status' => 'publish',
        'meta_key' => '_da_order_receipt_token',
        'meta_value' => $token,
        'posts_per_page' => 1,
    ));

    if (!$query->have_posts()) {
        wp_die('Invalid or expired receipt link.', 'Receipt', array('response' => 404));
    }

    $order_id = $query->posts[0]->ID;
    $already_sent = (int) get_post_meta($order_id, '_da_order_receipt_sent', true);
    if ($already_sent) {
        wp_die('Receipt already sent.', 'Receipt');
    }

    $sent = da_catering_yyc_child_send_order_receipt($order_id);
    if ($sent) {
        update_post_meta($order_id, '_da_order_receipt_sent', 1);
        update_post_meta($order_id, '_da_order_receipt_sent_at', current_time('mysql'));
        wp_die('Receipt sent successfully.', 'Receipt');
    }

    wp_die('Failed to send receipt. Please try again.', 'Receipt', array('response' => 500));
}
add_action('template_redirect', 'da_catering_yyc_child_handle_order_receipt');

function da_catering_yyc_child_handle_order_paid() {
    $token = isset($_GET['da_order_paid']) ? sanitize_text_field(wp_unslash($_GET['da_order_paid'])) : '';
    if (!$token) {
        return;
    }
    $query = new WP_Query(array(
        'post_type' => 'da_order',
        'post_status' => 'publish',
        'meta_key' => '_da_order_paid_token',
        'meta_value' => $token,
        'posts_per_page' => 1,
    ));

    if (!$query->have_posts()) {
        wp_die('Invalid or expired link.', 'Order Status', array('response' => 404));
    }

    $order_id = $query->posts[0]->ID;
    $already_paid = (int) get_post_meta($order_id, '_da_order_paid', true);
    if ($already_paid) {
        wp_die('Order already marked as paid.', 'Order Status');
    }

    update_post_meta($order_id, '_da_order_paid', 1);
    update_post_meta($order_id, '_da_order_paid_at', current_time('mysql'));
    da_catering_yyc_child_send_order_status_email($order_id, 'paid');
    wp_die('Order marked as paid.', 'Order Status');
}
add_action('template_redirect', 'da_catering_yyc_child_handle_order_paid');

function da_catering_yyc_child_handle_order_status() {
    $token = isset($_GET['da_order_status']) ? sanitize_text_field(wp_unslash($_GET['da_order_status'])) : '';
    $status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';
    if (!$token || !$status) {
        return;
    }
    $allowed = array('confirmed', 'in_progress', 'ready');
    if (!in_array($status, $allowed, true)) {
        wp_die('Invalid status.', 'Order Status', array('response' => 400));
    }

    $query = new WP_Query(array(
        'post_type' => 'da_order',
        'post_status' => 'publish',
        'meta_key' => '_da_order_status_token',
        'meta_value' => $token,
        'posts_per_page' => 1,
    ));

    if (!$query->have_posts()) {
        wp_die('Invalid or expired link.', 'Order Status', array('response' => 404));
    }

    $order_id = $query->posts[0]->ID;
    update_post_meta($order_id, '_da_order_status', $status);
    update_post_meta($order_id, '_da_order_status_updated_at', current_time('mysql'));
    da_catering_yyc_child_send_order_status_email($order_id, $status);
    wp_die('Order status updated.', 'Order Status');
}
add_action('template_redirect', 'da_catering_yyc_child_handle_order_status');
